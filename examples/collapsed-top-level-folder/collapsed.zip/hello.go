package main

import (
	"fmt"
)

func sayHelloTo(to string) {
	fmt.Print("👋 " + to)
}
